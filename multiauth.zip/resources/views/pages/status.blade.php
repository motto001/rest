@extends('layouts.main')

@section('content')

            <div class="row">
                <div class="col-md-12">

                    <p>{!! $error !!}</p>

                </div>
            </div>

@stop