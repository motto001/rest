<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <h2 style="margin-bottom:40px;">Ordinary User Panel Home Page</h2>

    <p><a href="<?php echo e(route('activated.protected')); ?>">Protected Page</a> - This page is protected with <code>activated</code> middleware.</p>

    <p><small>Users registered via Social providers are by default activated.</small></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>